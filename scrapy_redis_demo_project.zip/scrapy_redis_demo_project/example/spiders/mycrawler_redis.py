# coding: utf-8
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import Rule
from scrapy_redis.spiders import RedisCrawlSpider


class MyCrawler(RedisCrawlSpider):
    """Spider that reads urls from redis queue (myspider:start_urls)."""
    name = 'mycrawler_redis'

    # http://books.toscrape.com
    # http://quotes.toscrape.com
    # http://spidyquotes.herokuapp.com/scroll
    allowed_domains = ['books.toscrape.com', 'quotes.toscrape.com']
    # To allow any domain
    # allowed_domains = []

    redis_key = 'mycrawler:start_urls'

    rules = (
        # follow all links
        Rule(LinkExtractor(), callback='parse_page', follow=True),
    )

    def __init__(self, *args, **kwargs):
        # Dynamically define the allowed domains list.
        domain = kwargs.pop('domain', '')
        self.log("domain: %s" % domain)
        self.allowed_domains.extend(domain.split(','))
        self.log("self.allowed_domains: %s" % self.allowed_domains)

        super(MyCrawler, self).__init__(*args, **kwargs)

    def parse_page(self, response):
        return {
            'url': response.url,
            'title': response.css('title::text').re_first(r'\s*(.*)\s*'),
        }
